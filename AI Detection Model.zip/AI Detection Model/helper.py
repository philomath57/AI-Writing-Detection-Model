from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords
import re
import nltk

nltk.download('stopwords')
nltk.download('wordnet')

class Helper:
    def __init__(self) -> None:
        
        
        self.lemmatizer = WordNetLemmatizer()

    def cleaning(self, text):
        text = text.lower()
        text = re.sub('[^a-z\s]', '', text)
        data = []
        for word in text.split():
            if word not in stopwords.words("english"):
                data.append(word)
            else:
                data.append("")
        text = ' '.join(data)
        return text
        
    
    def lemmatization(self, text):
        words = text.split()
        collection = [self.lemmatizer.lemmatize(word, pos = 'v') for word in words]
        return ' '.join(collection)
    
    