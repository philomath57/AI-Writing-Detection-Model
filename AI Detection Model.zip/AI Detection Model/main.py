import pickle
import warnings
warnings.filterwarnings("ignore")
from helper import Helper
import streamlit as st


helper = Helper()

with open("AI_Model_RandomForest.pkl", "rb") as model:
    rf_model = pickle.load(model)
    
with open("AI_Model_Tfidf.pkl", "rb") as tfidf_model:
    vector_model = pickle.load(tfidf_model)
    

def query_creator(user_input):

  input_query = []

  # Preprocess
  user_input = helper.cleaning(user_input)
  user_input = helper.lemmatization(user_input)

  # Vectorization
  input_query_vector = vector_model.transform([user_input]).toarray()

  return input_query_vector

st.title("AI Detection Model")

generated_input = st.text_input("Please Enter Your Generated Input")

if st.button("Detect"):
    if rf_model.predict(query_creator(generated_input))[0] == "1":
        st.write("Content is AI Generated")
    else:
        st.write("Content is Human Generated")


